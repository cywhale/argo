#### ver 0.0.1 create argo_app.py
#### ver 0.0.2 endpoint: /api/floats/download, try websocket notify (not yet)
#### ver 0.0.3 move to argo_app and setup.py for package/Docker (work for net=host)/PyInstaller(not yet)
