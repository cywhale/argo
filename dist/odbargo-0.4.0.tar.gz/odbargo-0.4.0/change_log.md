#### ver 0.0.1 create argo_app.py
#### ver 0.0.2 endpoint: /api/floats/download, try websocket notify (not yet)
#### ver 0.0.3 move to argo_app and setup.py for package/Docker (work for net=host)/PyInstaller(not yet)
    -- create window installer by Inno Setup
	-- Make window installer can use Conda
	-- Installer/uninstall works for Conda/Python

#### ver 0.0.4 More customized functions/n1: adjustable running port
    -- modify Inno Setup to check_port feed %PORT% into odbargo_app
    -- add odbargo_app-0.0.4.installer.zip (.exe) in dist/ for downloading test

#### ver 0.0.5 Handle weekly update logic to POSTGIS db/n1
    -- convert numpy types to python natvie types when writing into db
    -- change build workflow, using pyproject.toml/drop some dummy columns in argofloats db
    -- update window installer (Inno Setup), reduce dummy file size greatly(not yet)/n1
    -- pyproject.toml build workflow trials (not yet)/n2
    -- drop pyproject.toml, use setup.py (python -m build) to fix no entry: No module named argo_app/n3
    -- need uvicorn[standard] to include Websocket after v0.30.6
    -- cancel argo_app app.py zipfile (equal size with .nc file)
    -- Filter duplicated WMS/add websocket onclose and error handling
    -- add TIMEOUT for powershell download python installer
    -- Change to BITS download python and fallback to web client method/n1, correctly detect result by enabledelayedexpansion/n2
    -- package upgrade but argopy1.0.0 still have bug (#412, wait official release)/n1
    -- Fix window installer for case without python installed
    -- Fixed argopy==0.1.17 (wait argopy1.0.0 bug fixation official release)/n2 
    -- try to use fixed requirements.txt in odbargo_app istallation (wait argopy1.0.0 bugfix releas)/n3
	-- add requirement.txt into window installer/n4
	-- add Installation guide in README.md/html
	-- Fix profiler all Unknown problem by using R08 reference table in argopy
	-- Research example of WMO690084 (Black Sea, O2 profile)

#### ver 0.0.6 move to argopy 1.1.0 before adding mcp
        -- mcp server trial/n1/deprecated: 20250610

#### ver 0.1.0 odbargo-cli: lightweight CLI deprecate FastAPI, argopy/milestone/n1
        -- try a windows executive
		-- prepare documentation in markdown/html

#### ver 0.1.1 add --insecure more to disable SSL cert if SSL error and retry downloading
#### ver 0.2.0 add odbargo-view plugin + subset workflows
        -- spawn spec-driven `odbargo_view` subprocess for dataset preview/plot/export
        -- extend slash CLI + WS bridge with `/view` help, alias subsets, and binary streaming fixes
        -- cap preview payloads, surface subset keys, and document usage in README_odbargo-view.md
#### ver 0.2.1 spatial-temporal filters + plot window fallback
        -- add `--bbox/--box` and `--start/--end` slash options layered with existing filters across preview/plot/export
        -- compose bbox/time predicates inside plugin filter pipeline and persist them for subset reuse
        -- open non-blocking matplotlib preview window when slash plots omit `--out`
        -- default map plots to LONGITUDE/LATITUDE axes, reshape values onto a lon/lat mesh, and support `--y` (field colour) plus `--cmap`
        -- allow `--order` sorting across preview/plot/export, run CLI exports in the background, enable readline history/navigation, and refresh README_odbargo-view.md with new usage examples
#### ver 0.2.2 optional viewer + packaging updates
        -- add PyInstaller one-file build commands for CLI and view plugin, keeping heavy deps in the companion binary
        -- make view plugin optional (`--plugin auto|view|none`), support explicit binaries, and emit clear messaging when disabled or missing
#### ver 0.2.3 fix matplotlib plot window cannot open (main CLI-VIEW devision and connection/n1)
#### ver 0.2.4 viewer grouping + stability + debug flag
        -- add `--group-by` with discrete keys, numeric binning (`PRES:<binwidth>`), and time resampling (`TIME:<freq>`);
           support `--agg mean|median|max|min|count`, capped legend series via `style.max_series`
        -- allow plotting against coordinate/dimension columns even when subset projection is narrowed; persist coords by default unless `--trim-dims`
        -- enforce `--limit` consistently across preview/plot/export; preview pagination reuses last displayed columns across `--cursor`
        -- single-port WS bridge supports viewer self-registration; robust handover to a single plugin reader (no concurrent recv)
        -- plot/export binary relay hardened; CSV streaming via `file_start` → binary chunks → `file_end` with SHA-256
        -- add env `ODBARGO_DEBUG=1` to enable CLI⇄plugin debug breadcrumbs (suppressed by default)
        -- README_odbargo-view.md refreshed with new options and examples
#### ver 0.2.5 Breaking completely deprecate old FastAPI structure and CLI packages        
        -- ensure_viewer(), and self‑registration stabilized; robust binary forwarding
        -- one-file pyinstaller packaging (.spec) and pip install (.toml), renew linux_cli and win_cli executive
#### ver 0.2.6 Fix plugin.view command through websocket and improve plot functions in specs/v0.2.1
        -- align map plotting across WS/stdio so `--bins`/`agg` actually trigger gridded `pcolormesh` (robust binning; scatter fallback remains with larger markers and debug breadcrumbs)
        -- share a single plotting core between CLI and plugin; spec v0.2.1 documents `cmap`, `pointSize`, and legend styling controls
        -- extend slash parser with `--legend`, `--legend-loc`, `--legend-fontsize`, `--point-size`, and comma-split `--group-by`; sequential colormaps now cycle distinct hues
        -- auto-scaled legend spacing for top/bottom placement, improved TIME tick formatting (day/month/year) with pandas/matplotlib, and palette cycling fully honoring `--cmap` for profile/timeseries
        -- add `--bins y=<ΔP>` for profile plots to aggregate depths by explicit dbar bins across CLI/WS (no implicit snapping)
        -- make `/view close` return promptly by offloading heavy netCDF closes to a background thread
#### ver 0.2.7 Case-insensitive view operations across CLI/WebSocket
        -- add `--case-insensitive-vars` flag (default on) and auto-normalise maps/timeseries for lower-case ERDDAP datasets
        -- ensure viewer lazily normalises already-open datasets, reuses column resolver for groupBy/map axes, and propagates filters under case-insensitive mode
        -- extend CLI slash handling to surface plugin error payloads and forward explicit case flags to WS-registered viewers
        -- update docs (README.md/html + Traditional Chinese) and specs/odbargo_view_spec_v_0_2_1.md; add tests for legacy → lowercase conversion, JSON between filters, map/timeseries plots, and CSV export
#### ver 0.2.8 No significant changes, only document all spec changes in specs/odbargo_view_spec_v_0_2_8.md
#### ver 0.2.9 Breaking new odbViz created to replace odbargo_view as a universal plotter for ODB CLI/n1

#### ver 0.3.0 odbViz antimeridian & viewer bridge polish
        -- fixed antimeridian handling: keep original bbox for projection, grid on 0–360, render on split −180..180 slices for basemap/cartopy, and normalize bbox extents to avoid wraparound
        -- ensured map plots ignore row limits during bbox detection to preserve seam awareness
        -- clarified keynotes doc for dateline handling and stabilized /view plot behavior for datasets opened via CSV or API-fed records
