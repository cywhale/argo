#### ver 0.0.1 create argo_app.py
#### ver 0.0.2 endpoint: /api/floats/download, try websocket notify (not yet)
#### ver 0.0.3 move to argo_app and setup.py for package/Docker (work for net=host)/PyInstaller(not yet)
    -- create window installer by Inno Setup
	-- Make window installer can use Conda
	-- Installer/uninstall works for Conda/Python

#### ver 0.0.4 More customized functions/n1: adjustable running port
